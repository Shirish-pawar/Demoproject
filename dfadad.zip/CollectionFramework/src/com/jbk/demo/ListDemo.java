package com.jbk.demo;

import java.util.ArrayList;
import java.util.List;

public class ListDemo {

	public static void main(String[] args) {
		 
		
		List<String> names=new ArrayList<>();
		
		names.add("java");
		names.add("php");
		names.add("cpp");
		
		

	}

}

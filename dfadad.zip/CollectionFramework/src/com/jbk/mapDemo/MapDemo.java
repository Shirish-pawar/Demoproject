package com.jbk.mapDemo;
import java.util.Map;
import java.util.HashMap;
public class MapDemo {

	public static void main(String[] args) {
		 
		Map<Integer, String> students=new HashMap<>();
		
		students.put(11, "vijay");
		students.put(22, " manish");
		students.put(11, "vijay");
    System.out.println(students);
	}

}

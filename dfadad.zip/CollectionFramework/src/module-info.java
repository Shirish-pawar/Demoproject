/**
 * 
 */
/**
 * @author HP
 *
 */
module CollectionFramework {
}